//
//  Entries.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 11/23/26.
//

//make an environment to check how it's stored and 
