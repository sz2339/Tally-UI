//
//  EntrySummary.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 11/20/26.
//
import Foundation

class EntrySummary: Identifiable {
    var id = UUID()
    
    var dateSubmitted: Date = Date.now
    
    //var summary: [] = similar format to entries but sums based on elements in history 
    var history: [Entry] = []//list of submitted entries
}
