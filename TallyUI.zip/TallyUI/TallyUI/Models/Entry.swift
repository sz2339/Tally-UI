//
//  Entry.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 11/20/26.
//
import Foundation

class Entry {
    
    private var itemName: String = ""
    private var calories: Int = 0
    
    //macros
    private var totalFat: Int = 0
    private var cholesterol: Int = 0
    private var sodium: Int = 0
    private var totalCarbs: Int = 0
    private var fiber: Int = 0
    private var totalSugars: Int = 0
    private var protein: Int = 0
    
    //micros
    private var vitaminD: Int = 0
    private var calcium: Int = 0
    private var iron: Int = 0
    private var potassium: Int = 0
    
    var description: String {
        "Item Name: \(itemName) \ncalories: \(calories)cal \ntotal fat: \(totalFat)g \ncholesterol: \(cholesterol)mg \nsodium: \(sodium)mg \ntotal carbs: \(totalCarbs)g \nfiber: \(fiber)g \ntotal sugars: \(totalSugars)g \nprotein: \(protein)g \nvitamin D: \(vitaminD)mcg \ncalcium: \(calcium)mg \niron: \(iron)mg \npotassium: \(potassium)mcg"
    }
    
    //itemName getter/setter
    func getItemName() -> String {itemName}
    func set(itemName: String){
        self.itemName = itemName
    }
    
    //calories getter/setter
    func getCalories() -> Int {calories}
    func set(calories: Int){
        self.calories = calories
    }
    
    //totalFat getter/setter
    func getTotalFat() -> Int {totalFat}
    func set(totalFat: Int){
        self.totalFat = totalFat
    }
    
    //cholesterol getter/setter
    func getCholesterol() -> Int {cholesterol}
    func set(cholesterol: Int){
        self.cholesterol = cholesterol
    }
    
    //sodium getter/setter
    func getSodium() -> Int {sodium}
    func set(sodium: Int){
        self.sodium = sodium
    }
    
    //totalCarbs getter/setter
    func getTotalCarbs() -> Int {totalCarbs}
    func set(totalCarbs: Int){
        self.totalCarbs = totalCarbs
    }
    
    //fiber getter/setter
    func getFiber() -> Int {fiber}
    func set(fiber: Int){
        self.fiber = fiber
    }
    
    //totalSugars getter/setter
    func getTotalSugars() -> Int {totalSugars}
    func set(totalSugars: Int){
        self.totalSugars = totalSugars
    }
    
    //protein getter/setter
    func getProtein() -> Int {protein}
    func set(protein: Int){
        self.protein = protein
    }
    
    //vitaminD getter/setter
    func getVitaminD() -> Int {vitaminD}
    func set(vitaminD: Int){
        self.vitaminD = vitaminD
    }
    
    //calcium getter/setter
    func getCalcium() -> Int {calcium}
    func set(calcium: Int){
        self.calcium = calcium
    }
    
    //iron getter/setter
    func getIron() -> Int {iron}
    func set(iron: Int){
        self.iron = iron
    }
    
    //potassium getter/setter
    func getPotassium() -> Int {potassium}
    func set(potassium: Int){
        self.potassium = potassium
    }
    
    init(itemName: String, calories: Int, totalFat: Int, cholesterol: Int, sodium: Int, totalCarbs: Int, fiber: Int, totalSugars: Int, protein: Int, vitaminD: Int, calcium: Int, iron: Int, potassium: Int){
//        super.init()
        set(itemName: itemName)
        set(calories: calories)
        
        set(totalFat: totalFat)
        set(cholesterol: cholesterol)
        set(sodium: sodium)
        set(totalCarbs: totalCarbs)
        set(fiber: fiber)
        set(totalSugars: totalSugars)
        set(protein: protein)
        
        set(vitaminD: vitaminD)
        set(calcium: calcium)
        set(iron: iron)
        set(potassium: potassium)
    }//init
}//Nutrition Entry end
