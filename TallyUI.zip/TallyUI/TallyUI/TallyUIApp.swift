//
//  TallyUIApp.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 10/22/26.
//

import SwiftUI

@main
struct TallyUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
