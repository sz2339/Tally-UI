//
//  DailyView.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 11/19/26.
//

import SwiftUI
import Charts

struct nutritionElem: Identifiable {
    var id = UUID()
    @State var type: String
    @State var count: Int
    @State var measureUnit: String
}

struct DailyView: View {
    
    //CHANGE ALL OF THESE TO LINK TO THE MOST RECENT APPENDED RECORD //add an nutrition record //similar to parks
    //change to chart by a daily value
    
    @State private var totalCalories = 2000
    
    var macroData: [nutritionElem] = [
        .init(type: "Total Fats", count: 50, measureUnit: "g"),
        .init(type: "Cholesterol", count: 50, measureUnit: "mg"),
        .init(type: "Sodium", count: 50, measureUnit: "mg"),
        .init(type: "Total Carbs", count: 50, measureUnit: "g"),
        .init(type: "Fiber", count: 50, measureUnit: "g"),
        .init(type: "Sugar", count: 50, measureUnit: "g"),
        .init(type: "Total Protein", count: 50, measureUnit: "g")
    ]
    
    var microData: [nutritionElem] = [
        .init(type: "Vitamin D", count: 50, measureUnit: "mcg"),
        .init(type: "Calcium", count: 50, measureUnit: "mg"),
        .init(type: "Iron", count: 50, measureUnit: "mg"),
        .init(type: "Potassium", count: 50, measureUnit: "mcg")
    ]
    
    var body: some View {
        
        NavigationStack {
            
            //for calories
            HStack(alignment: .firstTextBaseline) {
                Text("\(totalCalories)")
                    .font(.largeTitle)
                Text("cal")
                    .bold()
                Spacer()
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal)
            
            //picker and hover select over certain bars
            
            Chart {
                ForEach(macroData) {
                    BarMark(
                        x: .value("Type", $0.type),
                        y: .value("Value", $0.count)
                    )
                }
            }
            .padding()
            .frame(height: 400)
            .chartYAxis(.hidden)
            .chartXAxis {
                AxisMarks(position: .bottom, values: .automatic) { value in
                    AxisValueLabel() {
                        if let type = value.as(String.self) {
                            Text("\(type)")
                                .rotationEffect(.degrees(-35))
                        }
                    }
                    .offset(x: -10,y: 25)
                }
            }//Chart end
            
            //List from other logs
            
        }
        .safeAreaInset(edge: .top) {
            Text("Daily Tally")
                .fontWeight(.bold)
                .font(.largeTitle)
        }
        
    }//body
}//View

struct dailyValue {
    
    var RecFat = 78 //g
    var RecCholesterol = 300 //mg
    var RecSodium = 2300 //mg
    var RecCarbs = 275 //g
    var RecFiber = 28 //g
    var RecSugar = 50 //g
    var RecProtein = 50 //g
    
    var RecVitaminD = 20 //mcg
    var RecCalcium = 1300 //mg
    var RecIron = 18 //mg
    var RecPotassium = 4700 //mcg
    
}

#Preview {
    DailyView()
}
