//
//  FormView.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 11/19/26.
//

import SwiftUI

struct FormView: View {
    
    @State private var itemName = ""
    @State private var calories = 0
    
    @State private var totalFat = 0
    
    @State private var cholesterol = 0
    
    @State private var sodium = 0
    
    @State private var totalCarbs = 0
    @State private var fiber = 0
    @State private var totalSugars = 0
    
    @State private var protein = 0
    
    @State private var vitaminD = 0
    @State private var calcium = 0
    @State private var iron = 0
    @State private var potassium = 0
    
    var body: some View {
        
        NavigationStack {
            
            Form {
                
                Section(){
                    
                    TextField("Enter Item Name", text: $itemName)
                        .font(.title)
                        .keyboardType(.alphabet)
                    TextFieldLayout(nutrientListItemName: "Calories", measuringUnit: "cal", nutritentListItem: $calories)
                }
                
                Section(
                    header: Text("Macros")
                        .font(.title2)
                ){
                    //Fats
                    TextFieldLayout(nutrientListItemName: "Total Fats", measuringUnit: "g", nutritentListItem: $totalFat)
                    TextFieldLayout(nutrientListItemName: "Cholesterol", measuringUnit: "mg", nutritentListItem: $cholesterol)
                    TextFieldLayout(nutrientListItemName: "Sodium", measuringUnit: "mg", nutritentListItem: $sodium)
                    
                    //Carbs
                    TextFieldLayout(nutrientListItemName: "Total Carbs", measuringUnit: "g", nutritentListItem: $totalCarbs)
                    TextFieldLayout(nutrientListItemName: "Fiber", measuringUnit: "g", nutritentListItem: $fiber)
                    TextFieldLayout(nutrientListItemName: "Total Sugars", measuringUnit: "g", nutritentListItem: $totalSugars)
                    
                    //Protein
                    TextFieldLayout(nutrientListItemName: "Protein", measuringUnit: "g", nutritentListItem: $protein)
                }
                
                Section(
                    header: Text("Micros")
                        .font(.title2)
                ){
                    TextFieldLayout(nutrientListItemName: "Vitamin D", measuringUnit: "mcg", nutritentListItem: $vitaminD)
                    TextFieldLayout(nutrientListItemName: "Calcium", measuringUnit: "mg", nutritentListItem: $calcium)
                    TextFieldLayout(nutrientListItemName: "Iron", measuringUnit: "mg", nutritentListItem: $iron)
                    TextFieldLayout(nutrientListItemName: "Potassium", measuringUnit: "mg", nutritentListItem: $potassium)
                }
            }//Form end
            .navigationBarTitle("", displayMode: .inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack {
                        Image(systemName: "fork.knife")
                        Text("Nutrition Form")
                            .listRowBackground(Color.clear)
                            .fontWeight(.bold)
                            .font(.title)
                            .padding(.vertical, 0)
                    }
                }
                
//                ToolbarItem(placement: .bottomBar) {
//                }
            }//toolbar end
//            .toolbarBackground(.hidden, for: .bottomBar)
            .safeAreaInset(edge: .bottom) {
                Button {
                    
                    //validation before entry creation
                    
                    var entry : Entry = Entry(itemName: itemName, calories: calories, totalFat: totalFat, cholesterol: cholesterol, sodium: sodium, totalCarbs: totalCarbs, fiber: fiber, totalSugars: totalSugars, protein: protein, vitaminD: vitaminD, calcium: calcium, iron: iron, potassium: potassium)
                    
                    print(entry.description)
                    
                } label: {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                        Text("Submit")
                            .bold()
                    }.padding(5)
                }
                .buttonStyle(.borderedProminent)
            }.safeAreaPadding(.bottom)
        }//NavStack end
    }//body
}//View

struct TextFieldLayout: View {
    
    var nutrientListItemName: String
    var measuringUnit: String
    @Binding var nutritentListItem: Int
    
    var body: some View {
        
        VStack (alignment: .leading) {
            Text(nutrientListItemName)
                .bold()
                .foregroundStyle(.black)
            
            HStack {
                TextField("Enter \(nutrientListItemName)", value: $nutritentListItem, formatter: NumberFormatter())
                    .keyboardType(.numberPad) //uses a numeric keyboard
                Text("\(measuringUnit)")
            }
        }
    }//body
}//TextField Layout

#Preview {
    FormView()
}
