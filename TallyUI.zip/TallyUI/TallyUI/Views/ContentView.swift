//
//  ContentView.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 10/22/26.
//

import SwiftUI

enum Tabs: Hashable {
    case daily
    case form
    case logs
}

struct ContentView: View {
    
    @State private var selectedTab = Tabs.daily
    
    var body: some View {
        
        TabView(selection: $selectedTab) {
            Tab("Daily", systemImage: "house", value: Tabs.daily) {
                DailyView()
            }//Daily tab - look at daily log statitics
            
            Tab("Form", systemImage: "fork.knife", value: Tabs.form) {
                FormView()
            }//Form tab - enter in a food for today
            
            Tab("History", systemImage: "clock", value: Tabs.logs) {
                LogsView()
            }//History tab - look at past log statistics 
            
        }//TabView
        
    }//body
}//ContentView

#Preview {
    ContentView()
}
