//
//  LogsView.swift
//  TallyUI
//
//  Created by Selina Zhang (RIT Student) on 11/19/26.
//

import SwiftUI

struct LogsView: View {
    
    var body: some View {
        
        NavigationStack {
            
            //should be List(weekHistory)
            List {
                
            }//List end
            .toolbar {
                
            }//toolbar end
            
        }//NavStack end
        
    }//body
}//View 

#Preview {
    LogsView()
}
